googledatastore Package
=======================

:mod:`googledatastore` Package
------------------------------

.. automodule:: googledatastore.__init__
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`connection` Module
------------------------

.. automodule:: googledatastore.connection
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`datastore_v1_pb2` Module
------------------------------

.. automodule:: googledatastore.datastore_v1_pb2
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`helper` Module
--------------------

.. automodule:: googledatastore.helper
    :members:
    :undoc-members:
    :show-inheritance:
